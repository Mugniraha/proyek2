<?php $__env->startSection('content'); ?>
<nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="mb-5">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Kelola Jasa Service</li>
        <li class="breadcrumb-item active" aria-current="page">Dalam Proses</li>
    </ol>
</nav>
<table id="example" class="table" style="width:100%">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama customer</th>
            <th>jenis Kerusakan</th>
            <th>Deskripsi kerusakan</th>
            <th>Alamat</th>
            <th>Tanggal pemesanan</th>
            <th>Status</th>
        </tr>
    </thead>
    <?php
        $nomor = 1;
    ?>
    <?php $__currentLoopData = $jasaServis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($row->status === 'diproses'): ?>

    <tbody>

        <tr>
            <td><?php echo e($nomor++); ?></td>
            <td><?php echo e($row->user->username); ?></td>
            <td><?php echo e($row->kategoriJasa); ?></td>
            <td><?php echo e($row->deskripsiJasa); ?></td>
            <td><?php echo e($row->alamat); ?></td>
            <td><?php echo e(($row->tanggal)); ?></td>
            <td>
                <?php if($row->status === 'diproses'): ?>
                    <a href="<?php echo e(route('selesai', $row->idJasa)); ?>" class="btn btn-sm btn-primary w-100">Selesaikan</a>
                <?php elseif($row->status === 'ditolak'): ?>
                    <button class="btn btn-sm btn-danger w-100" disabled>Ditolak</button>
                <?php else: ?>
                    <button class="btn btn-sm btn-success w-75" disabled>Proses lainnya</button>
                <?php endif; ?>
            </td>

        </tr>
    </tbody>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\SEMESTER 3\Proyek 2\proyek2\resources\views/admin_konten/jsDalamProses.blade.php ENDPATH**/ ?>