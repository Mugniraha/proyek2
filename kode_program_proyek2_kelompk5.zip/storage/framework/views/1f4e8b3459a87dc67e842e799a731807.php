<?php $__env->startSection('content'); ?>
<nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="mb-5">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Kelola Jasa Service</li>
        <li class="breadcrumb-item active" aria-current="page">Pesanan Baru</li>
    </ol>
</nav>
<table id="example" class="table" style="width:100%">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama customer</th>
            <th>jenis Kerusakan</th>
            <th>Deskripsi kerusakan</th>
            <th>Alamat</th>
            <th>Tanggal pemesanan</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <?php
        $no = 1;
    ?>
    <?php $__currentLoopData = $jasaServis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($row->status === 'Menunggu Proses'): ?>

    <tbody>

        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($row->user->username); ?></td>
            <td><?php echo e($row->kategoriJasa); ?></td>
            <td><?php echo e($row->deskripsiJasa); ?></td>
            <td><?php echo e($row->alamat); ?></td>
            <td><?php echo e($row->tanggal); ?></td>
            <td><?php echo e($row->status); ?></td>
            <td>
                <a href="<?php echo e(route('terimaPesanan', $row->idJasa)); ?>" type="button" class="btn btn-sm btn-success btn-primary w-75">Terima</a>
                <a  href="<?php echo e(route('tolakPesanan', $row->idJasa)); ?>" type="button" class="mt-2 btn btn-sm btn-danger btn-primary w-75">Tolak</a>
            </td>
        </tr>
    </tbody>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\SEMESTER 3\Proyek 2\proyek2\resources\views/admin_konten/jsPesananBaru.blade.php ENDPATH**/ ?>