<?php $__env->startSection('konten'); ?>
        <section id="productspes">
        <div class="container-fluid">
            <div class="row">

                <div class="konten1 col py-3">
                    <div class="breadcrumb-item active" style="font-size: 19px" aria-current="page">Kelola Akun</div>
                    <div class="awal1">
                        <div class="container1 rounded p-5">

                            <div class="user-profile">
                                <div class="photoprofile">
                                    <div class="profile-image" style="pointer-events: none;">
                                        <?php if(session('user_profile_url_' . Auth::user()->idUser)): ?>
                                        <img id="profilePicture" src="<?php echo e(session('user_profile_url_' . Auth::user()->idUser)); ?>" alt="Profile Picture">
                                        <?php else: ?>
                                            <img id="profilePicture" src="<?php echo e(asset('images/profil1.png')); ?>" alt="Default Profile Picture">
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="user-name">
                                    <h4>
                                        <?php if(session('user') && session('user')->username): ?>
                                            <?php echo e(session('user')->username); ?>

                                        <?php else: ?>
                                            USERNAME
                                        <?php endif; ?>
                                    </h4>
                                </div>
                                <!-- Formulir untuk Unggah Foto -->
                                <form action="<?php echo e(route('updateFotoProfil')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="file" name="profil" accept="image/*" id="fileInput" style="display: none;" onchange="updateProfilePicture(this)">
                                    <button type="button" class="btn" onclick="document.getElementById('fileInput').click()">
                                        Ganti Foto
                                    </button>
                                    <button type="submit" class="btn" style="background-color: #4C6687; color: #fcf2c5;">
                                        Upload Foto
                                    </button>
                                </form>
                            </div>
                            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
                            <script>
                                function updateProfilePicture(input) {
                                    if (input.files && input.files[0]) {
                                        var file = input.files[0];
                                        var reader = new FileReader();

                                        reader.onload = function (e) {
                                            // Memperbarui gambar profil secara langsung dengan gambar yang dipilih
                                            document.getElementById('profilePicture').src = e.target.result;
                                        };

                                        // Membaca file yang dipilih sebagai URL data
                                        reader.readAsDataURL(file);

                                        var formData = new FormData();
                                        formData.append('profil', file);

                                        // Mengirim file ke server menggunakan AJAX
                                        axios.post("/profil/update-foto", formData, {
                                            headers: {
                                                'Content-Type': 'multipart/form-data',
                                            }
                                        })
                                        .then(response => {
                                            // Memperbarui gambar profil dengan respons server setelah pengunggahan berhasil
                                            document.getElementById('profilePicture').src = response.data.url + '?' + new Date().getTime();
                                        })
                                        .catch(error => {
                                            console.error('Error uploading profile picture:', error);
                                        });
                                    }
                                }


                                // Menambahkan listener untuk mengupdate gambar ketika ada perubahan pada input file
                                document.getElementById('fileInput').addEventListener('change', function() {
                                    updateProfilePicture(this);
                                });
                            </script>

                        </div>
                    </div>
                </div>


                <div class="konten2 col py-3">
                    <div class="awal2">
                        <div class="container2 rounded p-5">
                            <div class="user-profile">
                                <div class="user-name">
                                    <h4>Ubah Akun</h4>
                                </div>
                                <hr class="underline">
                            </div>
                            <form action="<?php echo e(route('updateProfileAndAddress')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="mb-3">
                                    <label for="formGroupExampleInputt" class="form-label">Username</label>
                                    <input type="text" class="form-control" name="username" placeholder="" value="<?php echo e(session('user')->username); ?>">
                                </div>
                                <div class="mb-3">
                                    <label for="formGroupExampleInput" class="form-label">Nama Legkap</label>
                                    <input type="text" class="form-control" name="name" placeholder="" value="<?php echo e(session('user')->name); ?>">
                                </div>
                                <div class="mb-3">
                                    <label for="formGroupExampleInput2" class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" placeholder="" value="<?php echo e(session('user')->email); ?>">
                                </div>
                                <div class="mb-3">
                                    <label for="formGroupExampleInput3" class="form-label">No Telepon</label>
                                    <input type="number" class="form-control" name="telp" placeholder="" value="<?php echo e(session('user')->telp); ?>">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlTextarea1" class="form-alamat">Alamat</label>

                                    
                                    <?php if(session()->has('alamat')): ?>
                                        <div class="alamat">
                                            <label for="exampleFormControlTextarea2" class="form-label">Nama Jalan</label>
                                            <input type="text" class="form-control" id="exampleFormControlTextarea2" name="nama_alamat" value="<?php echo e(session('alamat')->nama_alamat); ?>">

                                            <label for="exampleFormControlTextarea3" class="form-label">RT/RW</label>
                                            <input type="text" class="form-control" id="exampleFormControlTextarea3" name="rt_rw" value="<?php echo e(session('alamat')->rt_rw); ?>">

                                            <label for="exampleFormControlTextarea4" class="form-label">Desa</label>
                                            <input type="text" class="form-control" id="exampleFormControlTextarea4" name="desa" value="<?php echo e(session('alamat')->desa); ?>">

                                            <label for="exampleFormControlTextarea5" class="form-label">Kecamatan</label>
                                            <input type="text" class="form-control" id="eampleFormControlTextarea5" name="kecamatan" value="<?php echo e(session('alamat')->kecamatan); ?>">

                                            <label for="exampleFormControlTextarea6" class="form-label">Kabupaten</label>
                                            <input type="text" class="form-control" id="exampleFormControlTextarea6" name="kabupaten" value="<?php echo e(session('alamat')->kabupaten); ?>">
                                        </div>
                                    <?php else: ?>
                                        
                                        <div class="alamat">
                                            <label for="exampleFormControlTextarea2" class="form-label">Nama Jalan</label>
                                            <input type="text" class="form-control" id="exampleFormControlTextarea2" name="nama_alamat" placeholder="">

                                            <label for="exampleFormControlTextarea3" class="form-label">RT/RW</label>
                                            <input type="text" class="form-control" id="exampleFormControlTextarea3" name="rt_rw" placeholder="">

                                            <label for="exampleFormControlTextarea4" class="form-label">Desa</label>
                                            <input type="text" class="form-control" id="exampleFormControlTextarea4" name="desa" placeholder="">

                                            <label for="exampleFormControlTextarea5" class="form-label">Kecamatan</label>
                                            <input type="text" class="form-control" id="eampleFormControlTextarea5" name="kecamatan" placeholder="">

                                            <label for="exampleFormControlTextarea6" class="form-label">Kabupaten</label>
                                            <input type="text" class="form-control" id="exampleFormControlTextarea6" name="kabupaten" placeholder="">
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-success" style="background-color: #4C6687; color: #fcf2c5;">Simpan</button>
                                </div>
                            </form>
                            <hr class="underline">
                        </div>
                    </div>
                </div>

                <div class="konten2 col py-3">
                    <div class="awal2" >
                        <div class="container2 rounded p-5">
                            <div class="user-profile">
                                <div class="user-name">
                                    <h4>Ubah Password</h4>
                                </div>
                                <hr class="underline">
                            </div>
                            <div class="modal-body">
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>

                                <form action="<?php echo e(route('ubahKataSandi')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="mb-3">
                                        <label for="formGroupExampleInput" class="form-label">Password Lama</label>
                                        <input type="password" class="form-control" id="formGroupExampleInput" name="pw_lama" placeholder="" value="">
                                        
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleFormControlTextarea1" class="form-label">Password Baru</label>
                                        <input type="password" class="form-control" id="exampleFormControlTextarea1" name="pw_baru" placeholder="" rows="3">
                                    </div>

                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-success" style="background-color: #4C6687;color: #fcf2c5;">Simpan</button>
                                        
                                    </div>
                                </form>
                                <hr class="underline">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        </section>

<?php echo $__env->make('user-layout.nav-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\SEMESTER 3\Proyek 2\proyek2\resources\views/profilUser/kelolaUser.blade.php ENDPATH**/ ?>