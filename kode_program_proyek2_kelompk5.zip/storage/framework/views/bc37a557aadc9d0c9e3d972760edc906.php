<?php $__env->startSection('content'); ?>
<nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="mb-5">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">History</li>
        <li class="breadcrumb-item active" aria-current="page">Jasa Service</li>
    </ol>
</nav>
<table id="example" class="table" style="width:100%">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama customer</th>
            <th>Detail pesanan</th>
            <th>status</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $nomor = 1;
        ?>
        <?php $__currentLoopData = $jasaServis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($row->status === 'Selesai' || $row->status === 'ditolak'): ?>
            <tr>
                <td><?php echo e($nomor++); ?></td>
                <td><?php echo e($row->namaJasa); ?></td>
                <td>
                    <div class="card shadow p-2">
                        <table style="width: 100%; table-layout: fixed;">
                            <tr>
                                <td style="width: 30%;">Nama Jasa</td>
                                <td style="width: 5%;">:</td>
                                <td style="width: 65%;"><?php echo e($row->namaJasa); ?></td>
                            </tr>
                            <tr>
                                <td>Deskripsi Kerusakan</td>
                                <td>:</td>
                                <td><?php echo e(strlen($row->deskripsiJasa) > 2 ? substr($row->deskripsiJasa, 0, 100).'...' : $row->deskripsiJasa); ?></td>
                            </tr>
                            <tr>
                                <td>Alamat</td>
                                <td>:</td>
                                <td><?php echo e($row->alamat); ?></td>
                            </tr>
                            <tr>
                                <td>Tanggal Pemesanan</td>
                                <td>:</td>
                                <td><?php echo e($row->tanggal); ?></td>
                            </tr>
                            <tr>
                                <td>Tanggal Selesai</td>
                                <td>:</td>
                                <td><?php echo e($row->tanggal_selesai); ?></td>
                            </tr>
                        </table>
                        <a href="#" type="button" class="btn btn-sm btn-primary w-100 shadow" data-bs-toggle="modal" data-bs-target="#edit<?php echo e($row->idJasa); ?>" style="background-color:#4C6687 "><i class="fa-solid fa-magnifying-glass"></i> Lihat Detail</a>
                    </div>
                </td>
                <td>
                    <?php if($row->status === 'Selesai'): ?>
                    <a href="#" class="btn btn-sm btn-success w-100" disabled>Selesai</a>
                    <?php elseif($row->status === 'ditolak'): ?>
                    <a href="#" class="btn btn-sm btn-danger w-100" disabled>Ditolak</a>
                    <?php else: ?>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<!-- Modal Detail Pesanan -->
<?php $__currentLoopData = $jasaServis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="edit<?php echo e($row->idJasa); ?>" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Detail Pesanan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Isi Detail Pesanan -->
                    <table style="width: 100%; table-layout: fixed;">
                        <tr>
                            <td style="width: 30%;">Nama Jasa</td>
                            <td style="width: 5%;">:</td>
                            <td style="width: 65%;"><?php echo e($row->namaJasa); ?></td>
                        </tr>
                        <tr>
                            <td>Deskripsi Kerusakan</td>
                            <td>:</td>
                            <td><?php echo e($row->deskripsiJasa); ?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?php echo e($row->alamat); ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Pemesanan</td>
                            <td>:</td>
                            <td><?php echo e($row->tanggal); ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Selesai</td>
                            <td>:</td>
                            <td><?php echo e($row->tanggal_selesai); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\SEMESTER 3\Proyek 2\proyek2\resources\views/admin_konten/historyJaser.blade.php ENDPATH**/ ?>