
<?php $__env->startSection('content'); ?>
<h1>Jasa Service</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\SEMESTER 3\Proyek 2\proyek2\resources\views/admin_konten/service.blade.php ENDPATH**/ ?>