<?php $__env->startSection('konten'); ?>
        <section id="productspes">
            <div class="btn-top">
                <a href="<?php echo e(route('daftarpesanan.riwayat')); ?>"><button class="btnriwayat">Riwayat Pesanan</button></a>
                <a href="<?php echo e(route('daftarpesanan.riwayatService')); ?>"><button class="btnriwayat">Riwayat Service</button></a>
                <hr>
            </div>
        <?php $__currentLoopData = $dataPesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($pesanan->statusPesanan !== 'Selesai'): ?>
        <div class="container">
            <div class="row">
                <div class="cardpes">
                    <div class="card-top">
                        <div class="left-text">
                            <h6><i>JOYO ROYO BENGKEL WELDING</i></h6>
                        </div>
                        <div class="right-text">
                            <p class="statusPesanan"><?php echo e($pesanan->statusPesanan); ?></p>
                            <div class="vertical-line"></div>
                            <p class="idpesanan">ID:<?php echo e($pesanan->idPesanan); ?></p>
                        </div>
                    </div>
                    <div class="card-center">
                        <div class="left-col">
                            <?php if($pesanan->produk): ?>
                            <img src="<?php echo e(asset('storage/img/' . $pesanan->produk->gambar)); ?>" alt="Gambar Produk">
                            <?php else: ?>
                                <p>Gambar tidak tersedia</p>
                            <?php endif; ?>
                        </div>
                        <div class="center-col">
                            <table class="product-details">
                                <tr>
                                    <td  class="colhead" colspan="3"><?php echo e($pesanan->namaPesanan); ?></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td class="col-g">Panjang</td>
                                    <td class="narrow-column">:</td>
                                    <td class="col-g"><?php echo e($pesanan->panjang); ?></td>

                                </tr>
                                <tr>
                                    <td>Warna</td>
                                    <td class="narrow-column">:</td>
                                    <td><?php echo e($pesanan->warna); ?></td>
                                    <td class="col-g">Lebar</td>
                                    <td class="narrow-column">:</td>
                                    <td><?php echo e($pesanan->lebar); ?></td>
                                </tr>
                                <tr>
                                    <td>Bahan Rangka</td>
                                    <td class="narrow-column">:</td>
                                    <td><?php echo e(\App\Models\Bahan::find($pesanan->bahan)->namaBahan); ?></td>
                                    <td>Tinggi</td>
                                    <td class="narrow-column">:</td>
                                    <td ><?php echo e($pesanan->tinggi); ?></td>
                                </tr>
                                <tr>
                                    <td>Jumlah Barang</td>
                                    <td class="narrow-column">:</td>
                                    <td><?php echo e($pesanan->jumlahItem); ?></td>
                                </tr>
                                <tr>
                                    <td>Tanggal Pemesanan</td>
                                    <td class="narrow-column">:</td>
                                    <td><?php echo e($pesanan->tanggalPemesanan); ?></td>
                                </tr>
                                <tr>
                                    <td>Metode Pengiriman</td>
                                    <td class="narrow-column">:</td>
                                    <td>
                                            <?php echo e(\App\Models\Pengiriman::find($pesanan->metodePengiriman)->jenisPengiriman); ?>

                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="right-col">
                            <div class="dp-payment">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td><i>Harga DP :</i></td>
                                            <td class="gap" rowspan="2">
                                            </td>
                                            <td class="status-payment" rowspan="2"><i><?php echo e($pesanan->statusPembayaran); ?></i></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($pesanan->totalHarga / 2); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="payment">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td><i>Total Harga</i></td>
                                            <td>:</td>
                                            <td class="pricefull">Rp <?php echo e($pesanan->totalHarga); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="card-bottom">
                        <div class="btn-left">
                            <button type="button" class="btn btnprogres dropdown-toggle" id="toggleButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Progres Barang
                            </button>
                            <div class="dropdown-menu" aria-labelledby="toggleButton" style="background-color: #f4f5f7">
                                <div class="card-progres" id="cardProgres">
                                    <table class="progres-barang">
                                        <thead>
                                            <tr>
                                                <th colspan="3">Start</th>
                                                <th colspan="3">Process</th>
                                                <th colspan="3">Finishing</th>
                                                <th colspan="3">End</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $pesanan->pemantauans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemantauan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php if($pemantauan->porgres==25): ?>
                                                <td colspan="3"></td>
                                                <?php elseif($pemantauan->porgres==50): ?>
                                                <td colspan="3"><img class="card-img-left" src="<?php echo e(asset('storage/img/' . $pemantauan->gambar)); ?>" alt="Card image cap" width=75px height=75px></td>
                                                <?php elseif($pemantauan->porgres==75): ?>
                                                <td colspan="3"></td>
                                                <?php elseif($pemantauan->progres==100): ?>
                                                <td></td>
                                                <?php else: ?>

                                                <?php endif; ?>
                                            </tr>
                                            <tr>
                                                <td>Keterangan</td>
                                                <td>:</td>
                                                <td><?php echo e($pemantauan->keterangan); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Tanggal Update</td>
                                                <td>:</td>
                                                <td><?php echo e($pemantauan->tanggalUpdate); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <script>
                            document.addEventListener("DOMContentLoaded", function() {
                                // Dapatkan elemen tombol dan card-progres
                                const toggleButton = document.getElementById('toggleButton');
                                const cardProgres = document.getElementById('cardProgres');

                                // Tambahkan event listener untuk menampilkan card-progres saat tombol diklik
                                toggleButton.addEventListener('click', function() {
                                    // Cek apakah card-progres sedang ditampilkan
                                    const isCardVisible = cardProgres.classList.contains('show');

                                    // Toggle tampilan card-progres berdasarkan kondisi saat ini
                                    if (!isCardVisible) {
                                        // Tampilkan card-progres
                                        cardProgres.classList.add('show');
                                    } else {
                                        // Sembunyikan card-progres
                                        cardProgres.classList.remove('show');
                                    }
                                });
                            });
                        </script>


                        <div class="btn-right">
                            <?php if($pesanan->statusPesanan === 'Sudah Diverifikasi'): ?>
                            <a href="<?php echo e(route('pembayaran.transaksi', ['idPesanan' => $pesanan->idPesanan])); ?>">
                                <button class="btncall">Pembayaran DP</button>
                            </a>
                            <?php elseif($pesanan->statusPesanan === 'Menunggu Verifikasi'): ?>
                            <!-- Tambahkan kelas "disabled" dan atribut "disabled" untuk menonaktifkan tombol -->
                            <button class="btncall-disabled" disabled>Pembayaran DP</button>
                            <?php elseif($pesanan->statusPesanan === 'Sedang Diproses'): ?>
                            <button class="btncall-finish" disabled><i class="fa-solid fa-circle-check" style="color: #66ff70;"></i> Sudah Pembayaran DP</button>
                            <?php else: ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <?php else: ?>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

<?php echo $__env->make('user-layout.nav-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\SEMESTER 3\Proyek 2\proyek2\resources\views/daftarpesanan/index.blade.php ENDPATH**/ ?>