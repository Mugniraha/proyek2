<?php $__env->startSection('konten'); ?>
    <section id="productspes">
        <div class="kontenr">
            <div class="awal">
                <div class="container-row rounded p-2">
                    <div class="user-profile">
                        <?php if(session('user')): ?>
                        <div class="profile-image">
                            <?php if(session('user_profile_url_' . Auth::user()->idUser)): ?>
                                <img id="profilePicture" src="<?php echo e(session('user_profile_url_' . Auth::user()->idUser)); ?>" alt="Profile Picture">
                            <?php else: ?>
                                <img id="profilePicture" src="<?php echo e(asset('images/profil1.png')); ?>" alt="Default Profile Picture">
                            <?php endif; ?>
                        </div>

                        <?php else: ?>
                            <div class="profile-image">
                                <img id="profilePicture" src="<?php echo e(asset('images/profil1.png')); ?>" alt="Default Profile Picture">
                            </div>
                        <?php endif; ?>

                        <div class="user-name">
                            <h4 class="part2 p-2 text-dark rounded">
                                <?php if(session('user') && session('user')->username): ?>
                                    <?php echo e(session('user')->username); ?>

                                <?php else: ?>
                                    USERNAME
                                <?php endif; ?>
                            </h4>
                        </div>
                        <hr class="underline">
                    </div>
                    <div class="row">
                        <div class="content-row">
                            <div class="part1 p-2">
                                Nama Lengkap
                            </div>
                            <div class="part2 bg-light p-2 text-dark rounded">
                                <?php if(session('user')): ?>
                                    <?php echo e(session('user')->name); ?>

                                <?php else: ?>
                                    Belum diisi
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="content-row">
                            <div class="part1 p-2">
                                Email
                            </div>
                            <div class="part2 bg-light p-2 text-dark rounded">
                                
                                <?php if(session('user')): ?>
                                    <?php echo e(session('user')->email); ?>

                                <?php else: ?>
                                    Belum diisi
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="content-row">
                            <div class="part1 p-2">
                                No Telepon
                            </div>
                            <div class="part2 bg-light p-2 text-dark rounded">
                                
                                <?php if(session('user')): ?>
                                    <?php echo e(session('user')->telp); ?>

                                <?php else: ?>
                                    Belum diisi
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="content-row">
                            <div class="part1 p-2">
                                Alamat :
                            </div>
                        </div>
                    </div>

                    <div class="row mt-1">
                        <div class="content-row">
                            <div class="part1-nama-jalan p-2">
                                Nama Jalan
                            </div>
                            <div class="part2 bg-light p-2 text-dark rounded">
                                <?php if(session('alamat')): ?>
                                    <?php echo e(session('alamat')->nama_alamat); ?>

                                <?php else: ?>
                                    Belum diisi
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>

                    <div class="row mt-1">
                        <div class="content-row">
                            <div class="part1-nama-jalan p-2">
                                RT/RW
                            </div>
                            <div class="part2 bg-light p-2 text-dark rounded">
                                <?php if(session('alamat')): ?>
                                    <?php echo e(session('alamat')->rt_rw); ?>

                                <?php else: ?>
                                    Belum diisi
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-1">
                        <div class="content-row">
                            <div class="part1-nama-jalan p-2">
                                Desa
                            </div>
                            <div class="part2 bg-light p-2 text-dark rounded">
                                <?php if(session('alamat')): ?>
                                    <?php echo e(session('alamat')->desa); ?>

                                <?php else: ?>
                                    Belum diisi
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-1">
                        <div class="content-row">
                            <div class="part1-nama-jalan p-2">
                                Kecamatan
                            </div>
                            <div class="part2 bg-light p-2 text-dark rounded">
                                <?php if(session('alamat')): ?>
                                    <?php echo e(session('alamat')->kecamatan); ?>

                                <?php else: ?>
                                    Belum diisi
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-1">
                        <div class="content-row">
                            <div class="part1-nama-jalan p-2">
                                Kabupaten
                            </div>
                            <div class="part2 bg-light p-2 text-dark rounded">
                                <?php if(session('alamat')): ?>
                                    <?php echo e(session('alamat')->kabupaten); ?>

                                <?php else: ?>
                                    Belum diisi
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <br>


                    <div class="row">
                        <div class="btn-akun">
                            <a href="<?php echo e(route('KelolaUserIndex')); ?>" type="button" class="btn" style="background-color: #4C6687; color: #fcf2c5;"> Edit</a>
                        </div>
                    </div>
                </div>
            </div>
            

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

            <script>
                function openFileInput() {
                    // Trigger click event on the file input
                    document.getElementById('fileInput').click();
                }

                function updateProfilePicture(input) {
                    // Check if a file is selected
                    if (input.files && input.files[0]) {
                        var reader = new FileReader();

                        reader.onload = function (e) {
                            // Update the profile picture with the selected image
                            document.getElementById('profilePicture').src = e.target.result;
                        };

                        // Read the selected file as a data URL
                        reader.readAsDataURL(input.files[0]);
                    }
                }
            </script>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-layout.nav-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\SEMESTER 3\Proyek 2\proyek2\resources\views/profilUser/index.blade.php ENDPATH**/ ?>