<?php $__env->startSection('content'); ?>
<nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="mb-5">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Kelola Custom Barang</li>
        <li class="breadcrumb-item active" aria-current="page">Pesanan Baru</li>
    </ol>
</nav>
<table id="example" class="table" style="width:100%">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Pemesan</th>
            <th>Nama Pesanan</th>
            <th>Detail Custom</th>
            <th>Metode Pengiriman</th>
            <th>Tanggal pemesanan</th>
            <th>Jumlah Barang</th>
            <th>Harga DP</th>
            <th>Total Harga</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $no = 1;
        ?>
        <?php $__currentLoopData = $custom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($row->statusPesanan === 'Menunggu Verifikasi'): ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td></td>
            <td><?php echo e($row->namaPesanan); ?></td>
            <td>
                <div class="card shadow p-2">
                    <table style="width: 75%;">
                        <tr>
                            <td>Deskripsi Pesanan</td>
                            <td>:</td>
                            <td><?php echo e(strlen($row->deskripsiPesanan) > 2 ? substr($row->deskripsiPesanan, 0, 100).'...' : $row->deskripsiPesanan); ?></td>
                        </tr>
                        <tr>
                            <td>Bahan</td>
                            <td>:</td>
                            <td><?php echo e($row->bahan); ?></td>
                        </tr>
                        <tr>
                            <td>Panjang</td>
                            <td>:</td>
                            <td><?php echo e($row->panjang); ?> Cm</td>
                        </tr>
                        <tr>
                            <td>Lebar</td>
                            <td>:</td>
                            <td><?php echo e($row->lebar); ?> Cm</td>
                        </tr>
                        <tr>
                            <td>Tinggi</td>
                            <td>:</td>
                            <td><?php echo e($row->tinggi); ?> Cm</td>
                        </tr>
                        <tr>
                            <td>Warna</td>
                            <td>:</td>
                            <td><?php echo e($row->warna); ?></td>
                        </tr>
                    </table>
                    <a href="#" type="button" class="btn btn-sm btn-primary w-100 shadow" data-bs-toggle="modal" data-bs-target="#edit<?php echo e($row->idPesanan); ?>" style="background-color:#4C6687 "><i class="fa-solid fa-magnifying-glass"></i> Lihat Detail</a>
                </div>
            </td>
            <td><?php echo e($row->metodePengiriman); ?></td>
            <td><?php echo e($row->tanggalPemesanan); ?></td>
            <td><?php echo e($row->jumlahItem); ?></td>
            <td><?php echo e($row->totalHarga); ?></td>
            <td><?php echo e($row->totalHarga); ?></td>
            <td>
                <a href="<?php echo e(route('terimaPesanan',$row->idPesanan)); ?>" type="button" class="btn btn-sm btn-success btn-primary w-100" >Terima<a>
                <a  href="<?php echo e(route('tolakPesanan',$row->idPesanan)); ?>" type="button" class="mt-2 btn btn-sm btn-danger btn-primary w-100">Tolak</a>
            </td>
        </tr>
        <div class="modal fade modal-dialog-scrollable text-start" id="edit" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Edit Data</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Gambar</label>
                                <input type="file" class="form-control" id="formGroupExampleInput" name="gambar" placeholder="" value="">
                                <input type="hidden" value="">
                            </div>
                            <div class="mb-3">
                                <label for="formGroupExampleInput2" class="form-label">Deskripsi</label>
                                <textarea type="number" class="form-control" id="formGroupExampleInput2" name="deskripsi_galeri" placeholder="" value=""></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="formGroupExampleInput2" class="form-label">Harga</label>
                                <input type="number" class="form-control" id="formGroupExampleInput2" name="harga" placeholder="" value="">
                            </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-success">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal fade modal-dialog-scrollable" id="hapus" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Hapus Data</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                        <form action="" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <div class="modal-body">
                                <h3>YAKIN INGIN MENGHAPUS DATA?!</h3>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-danger">Hapus</button>
                            </div>
                        </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(session('success')): ?>
                <div class="alert alert-success mb-2">
                    <?php echo e(session('success')); ?>

                </div>
        <?php endif; ?>
    </tbody>
</table>

<?php $__currentLoopData = $custom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="edit<?php echo e($row->idPesanan); ?>" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Detail Pesanan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Isi Detail Pesanan -->
                    <table style="width: 75%;">
                        <tr>
                            <td>Deskripsi Pesanan</td>
                            <td>:</td>
                            <td><?php echo e($row->deskripsiPesanan); ?></td>
                        </tr>
                        <tr>
                            <td>Bahan</td>
                            <td>:</td>
                            <td><?php echo e($row->bahan); ?></td>
                        </tr>
                        <tr>
                            <td>Panjang</td>
                            <td>:</td>
                            <td><?php echo e($row->panjang); ?> Cm</td>
                        </tr>
                        <tr>
                            <td>Lebar</td>
                            <td>:</td>
                            <td><?php echo e($row->lebar); ?> Cm</td>
                        </tr>
                        <tr>
                            <td>Tinggi</td>
                            <td>:</td>
                            <td><?php echo e($row->tinggi); ?> Cm</td>
                        </tr>
                        <tr>
                            <td>Warna</td>
                            <td>:</td>
                            <td><?php echo e($row->warna); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade modal-dialog-scrollable text-start" id="tambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Tambah Data</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Gambar</label>
                        <input type="file" class="form-control" id="formGroupExampleInput" name="gambar" placeholder="" value="">
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Deskripsi</label>
                        <textarea type="number" class="form-control" id="formGroupExampleInput2" name="deskripsi_galeri" placeholder="" value=""></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Harga</label>
                        <input type="number" class="form-control" id="formGroupExampleInput2" name="harga" placeholder="" value="">
                    </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\SEMESTER 3\Proyek 2\proyek2\resources\views/admin_konten/cbPesananBaru.blade.php ENDPATH**/ ?>