<?php $__env->startSection('konten'); ?>
    <section id="productscos">
        <?php if($pesanan !== null && $produk !== null && $pengiriman !== null && $bahan !== null): ?>
        <div class="payment-container">
            <div class="payment-top">
                <div class="judul">
                    <p>PEMBAYARAN DP</p>
                </div>
                <div class="kodepesanan">
                    <p><?php echo e($pesanan->idPesanan); ?></p>
                </div>
            </div>
            <div class="payment-center">
                <hr>
                <div class="center-top">
                    <img class="card-img-top" src="<?php echo e(asset('storage/img/'.$produk->gambar)); ?>" alt="Card image cap">
                    <div class="keterangan">
                        <table class="product-keterangan">
                            <tr>
                                <td class="col-c"><?php echo e($pesanan->namaPesanan); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($pesanan->deskripsiPesanan); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="center-col-deskripsi">
                    <table class="product-details-payment">
                        <tr>
                            <td>Dimensi Produk</td>
                            <td class="narrow-column">:</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td class="col-d">Panjang</td>
                            <td class="narrow-column">:</td>
                            <td><?php echo e($pesanan->panjang); ?></td>
                        </tr>
                        <tr>
                            <td class="col-d">Lebar</td>
                            <td class="narrow-column">:</td>
                            <td><?php echo e($pesanan->lebar); ?></td>
                        </tr>
                        <tr>
                            <td class="col-d">Tinggi</td>
                            <td class="narrow-column">:</td>
                            <td><?php echo e($pesanan->tinggi); ?></td>
                        </tr>
                        <tr>
                            <td>Warna</td>
                            <td class="narrow-column">:</td>
                            <td><?php echo e($pesanan->warna); ?></td>
                        </tr>
                        <tr>
                            <td>Bahan Rangka</td>
                            <td class="narrow-column">:</td>
                            <td><?php echo e($bahan->namaBahan); ?></td>
                        </tr>
                        <tr>
                            <td>Jumlah Barang</td>
                            <td class="narrow-column">:</td>
                            <td><?php echo e($pesanan->jumlahItem); ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Pemesanan</td>
                            <td class="narrow-column">:</td>
                            <td><?php echo e($pesanan->tanggalPemesanan); ?></td>
                        </tr>
                        <tr>
                            <td>Metode Pengiriman</td>
                            <td class="narrow-column">:</td>
                            <td><?php echo e($pengiriman->jenisPengiriman); ?></td>
                        </tr>
                        <tr>
                            <td>Total Harga</td>
                            <td class="narrow-column">:</td>
                            <td><?php echo e($pesanan->totalHarga); ?></td>
                        </tr>
                    </table>
                    <div class="dp-price-payment">
                        <table>
                            <tbody>
                                <tr>
                                    <td><i>Harga DP</i></td>
                                    <td class="gap" rowspan="2">:</td>
                                    <td class="dp-price" rowspan="2"><i><?php echo e($pesanan->totalHarga / 2); ?></i></td>
                                </tr>
                            </tbody>
                        </table>     
                    </div>
                </div>
            </div>
            <div class="payment-bottom">
                <hr>
                <div class="btn-payment-dp">
                    <a href="#"><button class="btndp"><?php echo e($pesanan->statusPesanan); ?></button></a>
                </div>
            </div>
        </div> 
        <?php else: ?>
        <p>Data tidak ditemukan</p>
        <?php endif; ?>    
    </section>                
<?php echo $__env->make('user-layout.nav-produk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\SEMESTER 3\Proyek 2\proyek2\resources\views/pembayaran/index.blade.php ENDPATH**/ ?>