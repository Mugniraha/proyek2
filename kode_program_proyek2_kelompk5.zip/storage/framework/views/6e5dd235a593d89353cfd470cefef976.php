<?php $__env->startSection('content'); ?>
<nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="mb-5">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Kelola Custom Barang</li>
        <li class="breadcrumb-item active" aria-current="page">Selesai</li>
    </ol>
</nav>
<table id="example" class="table" style="width:100%">

    <thead>
        <tr>
            <th>No</th>
            <th class="w-75">Detail Custom</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $no = 1;
        ?>
        <?php $__currentLoopData = $custom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($row->statusPesanan === 'Selesai' || $row->statusPesanan === 'Ditolak'): ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td>
                <div class="card shadow p-2">
                    <table style="table-layout:fixed;">
                        <tr>
                            <td style="width:25%">Nama Pemesan</td>
                            <td style="width: 5%">:</td>
                            <td style="width: 70%"></td>
                        </tr>
                        <tr>
                            <td>Nama Pesanan</td>
                            <td>:</td>
                            <td><?php echo e($row->namaPesanan); ?></td>
                        </tr>
                        <tr>
                            <td>Deskripsi Pesanan</td>
                            <td>:</td>
                            <td><?php echo e(strlen($row->deskripsiPesanan) > 2 ? substr($row->deskripsiPesanan, 0, 100).'...' : $row->deskripsiPesanan); ?></td>
                        </tr>
                        <tr>
                            <td>Bahan</td>
                            <td>:</td>
                            <td><?php echo e($row->bahan); ?></td>
                        </tr>
                        <tr>
                            <td>Panjang</td>
                            <td>:</td>
                            <td><?php echo e($row->panjang); ?> Cm</td>
                        </tr>
                        <tr>
                            <td>Lebar</td>
                            <td>:</td>
                            <td><?php echo e($row->lebar); ?> Cm</td>
                        </tr>
                        <tr>
                            <td>Tinggi</td>
                            <td>:</td>
                            <td><?php echo e($row->tinggi); ?> Cm</td>
                        </tr>
                        <tr>
                            <td>Warna</td>
                            <td>:</td>
                            <td><?php echo e($row->warna); ?></td>
                        </tr>
                        <tr>
                            <td>Metode Pengiriman</td>
                            <td>:</td>
                            <td><?php echo e($row->metodePengiriman); ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Pemesanan</td>
                            <td>:</td>
                            <td><?php echo e($row->tanggalPemesanan); ?></td>
                        </tr>
                        <tr>
                            <td>Jumlah Item</td>
                            <td>:</td>
                            <td><?php echo e($row->jumlahItem); ?></td>
                        </tr>
                        <tr>
                            <td>Harga DP</td>
                            <td>:</td>
                            <td><?php echo e($row->totalHarga); ?></td>
                        </tr>
                        <tr>
                            <td>Total Harga</td>
                            <td>:</td>
                            <td><?php echo e($row->totalHarga); ?></td>
                        </tr>
                    </table>
                    <a href="#" type="button" class="btn btn-sm btn-primary w-100 shadow" data-bs-toggle="modal" data-bs-target="#edit<?php echo e($row->idPesanan); ?>" style="background-color:#4C6687 "><i class="fa-solid fa-magnifying-glass"></i> Lihat Detail</a>
                </div>
            </td>
            <td>
                <?php if($row->statusPesanan === 'Selesai'): ?>
                    <a href="#" class="btn btn-sm btn-success w-100" disabled>Selesai</a>
                    <?php elseif($row->statusPesanan === 'Ditolak'): ?>
                    <a href="#" class="btn btn-sm btn-danger w-100" disabled>Ditolak</a>
                    <?php else: ?>
                <?php endif; ?>
            </td>
            <td>
                <?php if($row->statusPesanan === 'Selesai'): ?>
                    <a href="#" type="button" class="btn btn-sm btn-warning btn-primary w-75" data-bs-toggle="modal" data-bs-target="#edit">Balas ulasan</a>
                    <?php else: ?>
                    <a href="#" type="button" class="btn btn-sm btn-warning btn-primary w-75 disabled" disabled readonly>Balas ulasan</a>
                <?php endif; ?>


            </td>
        </tr>

        <div class="modal fade modal-dialog-scrollable text-start" id="edit" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Balas Ulasan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label for="formGroupExampleInput2" class="form-label">Ulasan</label>
                                <textarea type="text" rows="10" class="form-control" id="formGroupExampleInput2" name="deskripsi_galeri" placeholder="" value=""></textarea>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-success">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(session('success')): ?>
                <div class="alert alert-success mb-2">
                    <?php echo e(session('success')); ?>

                </div>
        <?php endif; ?>

    </tbody>

</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\SEMESTER 3\Proyek 2\proyek2\resources\views/admin_konten/cbSelesai.blade.php ENDPATH**/ ?>