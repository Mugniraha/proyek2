@extends('user-layout.nav-produk')
@section('konten')
        <section id="products">
        <div class="container">
            <div class="row">
                @foreach($dataProduk as $produk)
                @if($produk->wishlist == 1)
                <div class="card">
                    <div class="card-top">
                        <img class="card-img-top" src="{{ asset('storage/img/'.$produk->gambar) }}" alt="Card image cap">
                    </div>
                    <div class="btn-top-wish">
                        <form action="{{ route('produk.store', $produk->idProduk) }}" method="POST">
                            @csrf
                            <input type="hidden" class="form-control" name="wishlist" value=0>
                            <button class="btnwhis-drop" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 512 512">
                                    <!--!Font Awesome Free 6.5.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path fill="#204d6f" d="M47.6 300.4L228.3 469.1c7.5 7 17.4 10.9 27.7 10.9s20.2-3.9 27.7-10.9L464.4 300.4c30.4-28.3 47.6-68 47.6-109.5v-5.8c0-69.9-50.5-129.5-119.4-141C347 36.5 300.6 51.4 268 84L256 96 244 84c-32.6-32.6-79-47.5-124.6-39.9C50.5 55.6 0 115.2 0 185.1v5.8c0 41.5 17.2 81.2 47.6 109.5z"/>
                                </svg>
                            </button>
                        </form>
                        <button class="btnulasan"><svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path fill="#4c6687" d="M168.2 384.9c-15-5.4-31.7-3.1-44.6 6.4c-8.2 6-22.3 14.8-39.4 22.7c5.6-14.7 9.9-31.3 11.3-49.4c1-12.9-3.3-25.7-11.8-35.5C60.4 302.8 48 272 48 240c0-79.5 83.3-160 208-160s208 80.5 208 160s-83.3 160-208 160c-31.6 0-61.3-5.5-87.8-15.1zM26.3 423.8c-1.6 2.7-3.3 5.4-5.1 8.1l-.3 .5c-1.6 2.3-3.2 4.6-4.8 6.9c-3.5 4.7-7.3 9.3-11.3 13.5c-4.6 4.6-5.9 11.4-3.4 17.4c2.5 6 8.3 9.9 14.8 9.9c5.1 0 10.2-.3 15.3-.8l.7-.1c4.4-.5 8.8-1.1 13.2-1.9c.8-.1 1.6-.3 2.4-.5c17.8-3.5 34.9-9.5 50.1-16.1c22.9-10 42.4-21.9 54.3-30.6c31.8 11.5 67 17.9 104.1 17.9c141.4 0 256-93.1 256-208S397.4 32 256 32S0 125.1 0 240c0 45.1 17.7 86.8 47.7 120.9c-1.9 24.5-11.4 46.3-21.4 62.9zM144 272a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm144-32a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm80 32a32 32 0 1 0 0-64 32 32 0 1 0 0 64z"/></svg>Ulasan</button>
                    </div>
                    <div class="card-body">
                        <div class="model">
                            <span class="fa fa-circle" id=""></span>
                            <span class="fa fa-circle" id=""></span>
                            <span class="fa fa-circle" id=""></span>
                        </div>
                        <div class="headline">
                            <p>{{ $produk->kategori }}</p>
                        </div>
                        
                        <button class="headProduk" onclick="toggleText('{{ $produk->idProduk }}')">
                            <h7 class="card-text" id="shortText{{ $produk->idProduk }}">
                                {{ strlen($produk->namaProduk) > 23 ? substr($produk->namaProduk, 0, 23) . '...' : $produk->namaProduk }}
                            </h7>
                            <h7 class="card-text" id="fullText{{ $produk->idProduk }}" style="display: none">
                                {{ $produk->namaProduk }}
                            </h7>
                        </button>
                        <p id="fullTextDetail{{ $produk->idProduk }}">Lebar : {{ $produk->lebar }}</p>
                        <p id="fullTextDetail{{ $produk->idProduk }}">Panjang : {{ $produk->panjang }}</p>
                        <p id="fullTextDetail{{ $produk->idProduk }}">Tinggi: {{ $produk->tinggi }}</p>
                        <p id="fullTextDetail{{ $produk->idProduk }}">Bahan: {{ $produk->bahan }}</p>
                        <p id="fullTextDetail{{ $produk->idProduk }}">Deskripsi: {{ strlen($produk->deskripsi_produk) > 25 ? substr($produk->deskripsi_produkk, 0, 25) . '...' : $produk->deskripsi_produkk }}</p>

                        <script>
                            function toggleText(productId) {
                                var shortText = document.getElementById('shortText' + productId);
                                var fullText = document.getElementById('fullText' + productId);
                                var fullTextDetail = document.querySelectorAll('#fullTextDetail' + productId);

                                // Menyembunyikan teks singkat dan menampilkan teks lengkap
                                if (shortText.style.display === 'none') {
                                    shortText.style.display = 'inline';
                                    fullText.style.display = 'none';
                                    
                                    // Menyembunyikan paragraf-detail
                                    fullTextDetail.forEach(function(element) {
                                        element.style.display = 'block';
                                    });
                                } else {
                                    shortText.style.display = 'none';
                                    fullText.style.display = 'inline';
                                    
                                    // Menampilkan paragraf-detail
                                    fullTextDetail.forEach(function(element) {
                                        element.style.display = 'none';
                                    });
                                }
                            }
                        </script>
                        <div class="harga">
                            <p><i>RP. {{ $produk->harga }}</i></p>
                        </div>
                    </div>
                    
                    <div class="btn">
                        
                        <button class="btnord">
                            <a href="{{ route('costumproduk.index', ['idProduk' => $produk->idProduk]) }}" style="text-decoration: none"><svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path fill="#204d6f" d="M471.6 21.7c-21.9-21.9-57.3-21.9-79.2 0L362.3 51.7l97.9 97.9 30.1-30.1c21.9-21.9 21.9-57.3 0-79.2L471.6 21.7zm-299.2 220c-6.1 6.1-10.8 13.6-13.5 21.9l-29.6 88.8c-2.9 8.6-.6 18.1 5.8 24.6s15.9 8.7 24.6 5.8l88.8-29.6c8.2-2.7 15.7-7.4 21.9-13.5L437.7 172.3 339.7 74.3 172.4 241.7zM96 64C43 64 0 107 0 160V416c0 53 43 96 96 96H352c53 0 96-43 96-96V320c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7-14.3 32-32 32H96c-17.7 0-32-14.3-32-32V160c0-17.7 14.3-32 32-32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H96z"/></svg>
                                Order
                            </a>
                        </button>
                    </div>
                </div>
                @else
            
                @endif
                @endforeach
            </div>
        </section>
